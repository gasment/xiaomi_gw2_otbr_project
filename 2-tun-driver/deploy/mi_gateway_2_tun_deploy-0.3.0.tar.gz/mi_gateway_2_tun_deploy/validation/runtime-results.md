# 实机验证记录

设备：lumi.gateway.mcn001，硬件 1.0，原厂固件 1.0.8_0004，Linux 4.9.84 #222。

用户已执行并提供日志确认：

- mg_abi_probe.ko 能加载、卸载。
- tun.ko 能加载，/sys/class/misc/tun/dev 为 10:200。
- 手动创建 /dev/net/tun 字符设备成功。
- tun-smoke 能通过 TUNSETIFF 创建 mgtun0 并配置 IPv6 地址。
- 成功从 TUN 读取内核 IPv6 echo 请求、写入模拟回复，内核收到回复：TUN_IPV6_ROUNDTRIP_PASS。
- 测试进程退出后 mgtun0 消失；提供的后续 dmesg 尾部没有 Oops/BUG。

尚未验证：长期稳定性、所有 TUN/TAP 模式、OTBR 完整运行、不同固件和硬件批次兼容性。
本包安装脚本未在实机执行。脚本使用的命令已逐项检查，设备节点检查表达式已在实机验证。启动链在本地隔离场景测试了前置 TUN 失败时仍继续原有启动，以及无原有钩子时回退原厂启动器。
