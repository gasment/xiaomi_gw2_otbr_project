#!/bin/sh
set -eu
BASE=$(CDPATH= cd "$(dirname "$0")" && pwd)
CTL=/data/mi-gw2-post-init/post-initctl.sh
fail() { echo "POST_INIT_INSTALL_ERROR: $*" >&2; exit 1; }
[ "$(id -u)" = 0 ] || fail 'Run as root on the gateway.'
[ -x /bin/fw_manager.sh ] || fail 'Stock Xiaomi service launcher not found.'
for T in awk cat cmp cp date grep kill mkdir mv rm rmdir sed sha256sum sh sync touch; do
    command -v "$T" >/dev/null 2>&1 || fail "Missing command: $T"
done
cd "$BASE"
sha256sum -c SHA256SUMS
for SCRIPT in post-initctl.sh migrate-legacy.sh install-common.sh factory-reset.sh boot-manager.sh modules/*.sh; do sh -n "$SCRIPT"; done

sh "$BASE/install-common.sh"

if [ -f /data/otbr/start.sh ]; then
    mkdir -p /data/otbr/previous
    if [ -f /data/otbr/boot-manager.sh ] && ! cmp -s "$BASE/boot-manager.sh" /data/otbr/boot-manager.sh; then
        cp /data/otbr/boot-manager.sh "/data/otbr/previous/boot-manager.sh.$(date +%Y%m%d-%H%M%S)"
    fi
    cp "$BASE/boot-manager.sh" /data/otbr/boot-manager.sh.new
    chmod 700 /data/otbr/boot-manager.sh.new
    mv -f /data/otbr/boot-manager.sh.new /data/otbr/boot-manager.sh
fi

if [ -f /data/tun/enabled ] && [ -x /data/tun/start-tun.sh ]; then
    "$CTL" add tun /data/mi-gw2-post-init/modules/tun.sh
fi
if [ -f /data/ble-spec-cache/installed ] && [ ! -f /data/ble-spec-cache/disabled ] && [ -x /data/ble-spec-cache/start.sh ]; then
    "$CTL" add ble-cache /data/mi-gw2-post-init/modules/ble-cache.sh
fi
if [ -f /data/otbr/enabled ] && [ -x /data/otbr/boot-manager.sh ]; then
    "$CTL" add otbr /data/mi-gw2-post-init/modules/otbr.sh
fi

"$CTL" check
sync
echo 'POST_INIT_MODULAR_INSTALLED: stock startup remains the final unconditional anchor.'
echo 'Reboot manually after reviewing /data/scripts/post_init.sh and the enabled module list.'
